surplus|federal|mod
surplus|budget|nn
resulted|surplus|subj
resulted|combination|from
growth|strong|mod
combination|growth|of
inflation|low|mod
growth|inflation|conj
unemployment|declining|mod
inflation|unemployment|conj
unemployment|and|punc
efficiency|improving|mod
unemployment|efficiency|conj
came from|much|subj
taxes|excess|mod
taxes|social security|nn
taxes|payroll|nn
came from|taxes|obj
factors|other|mod
factors|enabling|mod
included|factors|subj
included|treasury|obj
treasury|and|punc
cooperation|federal reserve|nn
treasury|cooperation|conj
restraint|spending|nn
cooperation|restraint|on
restraint|that|whn
kept|restraint|subj
rates|interest|nn
kept|rates|obj
kept|low|mod
prosperous|increasingly|mod
agreement|1997|num
agreement|white house|by
white house|and|punc
white house|congress|conj
congress|balance|rel
balance|congress|subj
balance|budget|obj
predicted|white house|subj
predicted|surpluses|obj
15|next|num-mod
years|15|amount-value
surpluses|years|over
optimistic|less|mod
five|more than|num-mod
years|five|amount-value
projections|years|for
were|difficult|pred
president|clinton|person
president|favored|vrel
favored|president|obj
favored|using|mod
using|most|obj
most|surplus|of
surplus|social security|for
wanted|also|mod-before
wanted|he|subj
wanted|fix|fc
fix|he|subj
problems|medicare|gen
problems|financial|mod
fix|problems|obj
fix|and|punc
fix|expand|conj
expand|he|subj
expand|it|obj
expand|include|mod
coverage|prescription drug|nn
include|coverage|obj
iras|new|mod
create|iras|obj
options|investment|nn
iras|options|with
needs|military|mod
military|and|punc
military|other|conj
needs|critical|mod
create|needs|on
chairman|federal reserve|nn
chairman|alan greenspan|person
chairman|favored|vrel
favored|chairman|obj
favored|strengthening|mod
strengthening|social security|obj
strengthening|and|punc
strengthening|paying off|conj
debt|federal|mod
paying off|debt|obj
robert rubin|treasury secretary|nn
urged|robert rubin|subj
cuts|interest|nn
cuts|rate|nn
urged|cuts|obj
cuts|and|punc
contributions|imf|nn
cuts|contributions|conj
democrats|and|punc
both|republicans|nn
democrats|both|conj
both|favored|vrel
favored|both|obj
favored|using|mod
using|most|obj
most|surplus|of
surplus|social security|for
tax|republicans|nn
tax|wanted|mod
tax|income|nn
cuts in|tax|subj
cuts in|everything|obj
everything|social security|except
social security|and|punc
social security|increase|conj
contributions|allowed|mod
contributions|ira|nn
increase|contributions|in
supported|they|subj
deductions|self-employed|mod
deductions|health insurance|nn
supported|deductions|obj
deductions|and|punc
deductions|increases|conj
increases|medicare|for
benefits|veterans|gen
benefits|health|nn
medicare|benefits|conj
benefits|and|punc
benefits|schools|conj
favored|democrats|subj
credits|tax|nn
favored|credits|obj
caregivers|family|nn
credits|caregivers|for
candidate|presidential|mod
candidate|al gore|person
favored|candidate|subj
increases|spending|nn
favored|increases|obj
favored|while|mod
while|favored|comp1
favored|george bush|subj
cuts|tax|nn
favored|cuts|obj
cuts|and|punc
increases|smaller|mod
increases|spending|nn
cuts|increases|conj
both|supported|vrel
supported|both|obj
supported|stashing|mod
stashing|surplus|obj
surplus|social security|from
box|lock|nn
social security|box|in
box|pay|rel
pay|box|subj
pay|down|guest
pay|debt|obj
