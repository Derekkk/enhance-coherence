changing|bookselling|subj
changing|dramatically|mod
chains|big|mod
proliferating|chains|subj
proliferating|and|punc
proliferating|squeezing out|conj
squeezing out|chains|subj
bookstores|independent|mod
squeezing out|bookstores|obj
half|independents|nn
half|lost|mod
share|their|gen
share|market|nn
years|six|amount-value
share|years|in
years|and|punc
years|many|conj
half|closed|rel
closed|half|obj
closed|share|subj
sold|now|guest
sold|books|obj
outlets|nontraditional|mod
sold|outlets|in
sold|including|mod
including|book|subj
stores|discount|nn
including|stores|obj
stores|and|punc
stores|internet|conj
represents|american bookseller association|subj
owners|private|mod
owners|bookstore|nn
represents|owners|obj
represents|and|punc
represents|sponsors|conj
sponsors|american bookseller association|subj
expo|book|nn
sponsors|expo|obj
convention|annual|mod
expo|convention|appo
brought|aba|subj
suits|antitrust|mod
brought|suits|obj
houses|top|mod
houses|publishing|nn
suits|houses|against
houses|and|punc
houses|borders|conj
borders|and|punc
& noble for making secret deals that undercut independents, resulting in a $25 million payment by publishers to booksellers.|barnes|nn
borders|& noble for making secret deals that undercut independents, resulting in a $25 million payment by publishers to booksellers.|conj
censured|it|subj
censured|author|obj
author|frank mccourt|person
author|participating|for
participating|it|subj
advertising|chainstore|nn
participating|advertising|in
barnesandnoble.com|challenged|mod
claim|barnesandnoble.com|gen
advertising|claim|appo
participating|"|punc
participating|if|c
have|we|subj
have|your|obj
book|nobody|obj1
book|does|obj2
opposition|successful|mod
&n's plan to purchase the largest book distributor (threatening independents with reduced service and compromised records), and joined the northern california independent booksellers association in urging collection of taxes from on-line bookstores.|b|nn
opposition|&n's plan to purchase the largest book distributor (threatening independents with reduced service and compromised records), and joined the northern california independent booksellers association in urging collection of taxes from on-line bookstores.|to
competition|online|mod
meet|competition|obj
opened|aba|subj
sense|book|nn
opened|sense|obj
sense|and|punc
sense|contentville|conj
selling|online|mod
contentville|selling|conj
selling|and|punc
sites|commentary|nn
selling|sites|conj
sites|serving as|rel
serving as|site|subj
serving as|hubs|obj
stores|individual|mod
hubs|stores|for
sales|online|mod
sales|book|nn
captured|sales|subj
captured|2%|obj
2%|market|of
market|1999|in
captured|and|punc
captured|projected|conj
projected|sales|obj
projected|rise|mod
rise|sale|subj
rise|10%|to
10%|2002|by
10%|and|punc
10%|18%|conj
18%|2003|by
competition|online|mod
led|competition|subj
led|barnesandnoble.com|obj
barnesandnoble.com|sell|rel
sell|barnesandnoble.com|subj
sell|shares|obj
shares|public|to
com|b|nn
com|&n and amazon to establish their own distribution centers to increase profits, and barnesandnoble.|nn
shares|com|conj
com|and|punc
com|borders.com|conj
borders.com|match|rel
match|borders.com|subj
match|amazon.com|obj
amazon.com|halving|in
prices|best-seller|nn
halving|prices|obj
sales|online|mod
hurt|sales|subj
hurt|mail-order|obj
mail-order|and|punc
sales|book|nn
sales|club|nn
mail-order|sales|conj
stay|competitive|desc
booksellers|traditional|mod
increased|booksellers|subj
service|personal|mod
increased|service|obj
increased|sponsored|conj
sponsored|booksellers|subj
events|special|mod
sponsored|events|obj
sponsored|and|punc
sponsored|began|conj
began|booksellers|subj
began|selling|fc
selling|bookseller|subj
broad|offering|nn
search|broad|subj
search|capabilities|obj
