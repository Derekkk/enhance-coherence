is|thought|pred
partly|at least|mod
caused|partly|amod
caused|by|by-subj
caused|emissions|by
emissions|waste|of
gases|industrial|mod
thought|like|comp1
like|gases|subj
like|carbon dioxide|obj
carbon dioxide|produced|vrel
produced|carbon dioxide|obj
produced|by|by-subj
produced|burning|by
burning|gas|subj
burning|fossil fuels|obj
fossil fuels|coal|like
coal|oil|conj
oil|and|punc
gas|natural|nn
oil|gas|conj
trap|emissions|subj
trap|solar radiation|obj
trap|and|punc
trap|produce|conj
produce|emissions|subj
effect|greenhouse|nn
produce|effect|obj
methane|and|punc
emissions|nitrous oxide|nn
methane|emissions|conj
ruminants|agriculture|nn
ruminants|(|punc
emissions|ruminants|from
ruminants|and|punc
ruminants|manure|conj
make|)|punc
make|methane|subj
make|up|guest
make|8%|obj
gases|greenhouse|nn
8%|gases|of
emissions|sulfur dioxide|nn
controls|emissions|on
reduce|controls|subj
reduce|balancing|obj
balancing|cooling|rel
cooling|balancing|subj
cooling|effect|obj
warming|already|mod
appearances|causes|nn
frequent|more|mod
appearances|frequent|mod
appearances|el nino|nn
warm|receding|mod-before
receding|appearance|subj
receding|shorelines|obj
warm|longer|amod
warm|appearances|subj
warm|seasons|mod
earth|slower|mod
spin|earth|subj
affects|it|subj
affects|habitats|obj
affects|and|punc
affects|threatens|conj
threatens|it|subj
life|marine|mod
threatens|life|obj
are|not|neg
reduced|emissions|obj
temperature|average|mod
temperature|surface|mod
rise|temperature|subj
degrees|2-6|amount-value
rise|degrees|obj
century|next|post
degrees|century|over
rise|bringing|mod
bringing|temperature|subj
dislocation|widespread|mod
dislocation|climatic|mod
climatic|ecological|conj
ecological|and|punc
ecological|economic|conj
bringing|dislocation|obj
floods|and|punc
floods|droughts|conj
increase|floods|subj
increase|frequency|in
frequency|and|punc
frequency|intensity|conj
ice|melting|mod
ice|polar|mod
cause|ice|subj
levels|rising|mod
levels|sea|nn
cause|levels|obj
increase|malaria|subj
loss|habitat|nn
rates|loss|of
loss|and|punc
extinction|species|nn
loss|extinction|conj
increase|rates|subj
need|communities|subj
need|adapt|fc
adapt|community|subj
conditions|new|mod
adapt|conditions|to
argue|skeptics|subj
argue|that|c
activities|human|nn
have|activities|subj
influence|little|mod
have|influence|obj
influence|climate|on
most|observed|vrel
warming|most|subj
is|due to|pred
causes|natural|mod
is|causes|due to
causes|changes|like
changes|solar radiation|in
solar radiation|or|punc
solar radiation|circulation|conj
waters|heat-bearing|mod
waters|ocean|nn
circulation|waters|of
measurements|taken|vrel
taken|measurements|obj
taken|by|by-subj
taken|satellites|by
found|measurements|subj
found|rise|fc
rise|temperature|subj
atmosphere|upper|mod
rise|atmosphere|in
models|computer|nn
are|unreliable|pred
century|next|post
warming|century|over
be|most|pred
most|pronounced|vrel
pronounced|most|obj
pronounced|winter|in
in|at|conj
in|night|at
at|and|punc
at|in|conj
regions|sub-arctic|nn
at|regions|in
be|doing|conj
doing|warming|subj
doing|harm|obj
doing|and|punc
doing|creating|conj
creating|warming|subj
creating|benefits|obj
growing seasons|longer|mod
benefits|growing seasons|like
growing seasons|and|punc
growth|faster|mod
growth|plant|nn
growing seasons|growth|conj
argues|industry|subj
argues|that|c
reducing|industry|subj
reducing|use|obj
use|fossil fuels|of
harm|economic|mod
cause|harm|obj
harm|consumers|to
