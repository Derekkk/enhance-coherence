component|chemical|mod
is|component|pred
component|plastic explosives|in
found|traces|obj
found|wreckage|on
flight|twa|nn
wreckage|flight|from
flight|800|num
flight|that|whn
crashed|flight|subj
crashed|7/17/96|obj
found|petn|obj
found|bombs|in
bombs|and|punc
bombs|surface-to-air missiles|conj
chemicals|precursor|nn
agent|nerve|nn
chemicals|agent|for
agent|vx|person
include|chemicals|subj
trichloride|phosphorous|mod
include|trichloride|obj
pentasulfide|phosphorous|mod
trichloride|pentasulfide|conj
ethylamine|diisopropyl|nn
pentasulfide|ethylamine|conj
ethylamine|and|punc
methylphosphonothionate|ethyl|nn
ethylamine|methylphosphonothionate|conj
methylphosphonothionate|known|pnmod
known|empta|as
traces|empta|nn
found|traces|obj
found|soil|in
shifa pharmaceutical industries company|khartoum|gen
soil|shifa pharmaceutical industries company|outside
shifa pharmaceutical industries company|target|appo
strike|1998|num
strike|us|nn
strike|air|mod
target|strike|of
found|empta|obj
found|blood|in
blood|man|of
man|killed|vrel
killed|man|obj
killed|by|by-subj
killed|vx|by
attack|1994|num
vx|attack|in
cult|japanese|mod
attack|cult|by
has|empta|subj
uses|industrial|mod
has|uses|obj
papers|scientific|mod
use|fungicides|in
fungicides|and|punc
agents|anti-microbial|mod
fungicides|agents|conj
breaks down|empta|subj
breaks down|empa|into
aldrich chemical co.|milwaukee|in
makes|aldrich chemical co.|subj
makes|empta|obj
makes|and|punc
makes|sells|conj
sells|aldrich chemical co.|subj
sells|it|obj
sells|research|for
mobil corp.|and|punc
mobil corp.|international chemical industries of america|conj
researched|mobil corp.|subj
applications|commercial|mod
researched|applications|obj
applications|empta|for
banned|dutch|subj
banned|shipment|obj
of|"|punc
chemicals|dual-use|nn
chemicals|"|punc
shipment|chemicals|of
chemicals|sudan|to
sudan|1998|in
found|french|subj
components|vx|nn
components|chemical|mod
found|components|obj
warheads|iraqi|mod
components|warheads|on
claimed|baghdad|subj
had|once|mod-before
claimed|had|fc
had|it|subj
chemicals|sufficient|mod
had|chemicals|obj
chemicals|make|rel
make|chemical|subj
tons|500|amount-value
make|tons|obj
tons|vx|of
used|ch3poc12|obj
used|make|mod
make|ch3poc12|subj
make|sarin|obj
sarin|and|punc
agents|other|mod
agents|chemical|nn
sarin|agents|conj
tons|thirty|amount-value
taken|tons|obj
plant|chemical|mod
taken|plant|from
plant|mostar|in
mostar|1992|in
chemical weapons convention|1993|num
chemical weapons convention|ratified|vrel
ratified|chemical weapons convention|obj
ratified|by|by-subj
ratified|us|by
us|and|punc
us|soviet union|conj
soviet union|but|punc
soviet union|not|punc
soviet union|sudan|conj
sudan|or|punc
sudan|yugoslavia|conj
development|bans|nn
yugoslavia|development|conj
development|production|conj
production|stockpiling|conj
stockpiling|transfer|conj
transfer|and|punc
transfer|use|conj
weapons|chemical|mod
use|weapons|of
requires|law|subj
requires|destruction|obj
agents|deadly|mod
agents|chemical|nn
destruction|agents|of
include|monitors|subj
include|organization|obj
organization|prohibition|for
weapons|chemical|nn
prohibition|weapons|of
experts|un|nn
experts|weapons|nn
weapons|experts|conj
experts|and|punc
experts|human rights watch|conj
