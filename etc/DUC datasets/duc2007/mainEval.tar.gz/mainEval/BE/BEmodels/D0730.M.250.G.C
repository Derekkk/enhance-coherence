liv|(|punc
line-item veto|liv|abbrev
liv|)|punc
sought|line-item veto|obj
century|tool|as
tool|limit|rel
limit|tool|subj
spending|pork barrel|nn
limit|spending|obj
spending|which|whn
reviled|traditionally|amod
reviled|spending|obj
reviled|most|as
deployed|cynically|mod-before
president|deployed|rel
deployed|century|subj
utilitarian|least|post
form|utilitarian|subj
form|largess|of
included|budget|subj
included|$300,000|obj
$300,000|enhancing|for
enhancing|budget|subj
enhancing|flavor|obj
flavor|peanuts|of
peanuts|$150,000|conj
competitiveness|peanut|mod
$150,000|competitiveness|for
competitiveness|and|punc
competitiveness|$250,000|conj
research|pickle|nn
$250,000|research|for
president|clinton|person
said|president|subj
said|is|fc
tool|important|mod
is|tool|pred
tool|striking|for
striking|liv|subj
spending|unnecessary|mod
striking|spending|obj
preserving|integrity|obj
spending|federal|mod
integrity|spending|of
preserving|and|punc
preserving|enlivening|conj
debate|public|nn
enlivening|debate|obj
over|make|pcomp-c
use|best|mod
make|use|obj
funds|public|mod
use|funds|of
contended|general|subj
contended|that|c
represents|liv|subj
exercise|presidential|mod
represents|exercise|obj
authority|spending|nn
exercise|authority|of
authority|delegated|vrel
delegated|authority|obj
delegated|by|by-subj
delegated|congress|by
lord|bryce|person
said|lord|subj
desired|"|punc
said|desired|fc
desired|liv|obj
desired|by|by-subj
men|enlightened|mod
desired|men|by
desired|and|punc
desired|save|conj
save|liv|subj
millions|nation|nn
save|millions|obj
millions|dollars|of
save|year|mod
is|prerogative|pred
prerogative|given|pnmod
governors|43|num
given|governors|to
congress|republican-controlled|mod
passed|congress|subj
passed|line-item veto act|obj
line-item veto act|which|whn
went into|line-item veto act|subj
went into|effect|obj
went into|january 1997|mod
president|clinton|person
used|president|subj
used|authority|obj
authority|veto|rel
veto|authority|subj
items|82|num
veto|items|obj
bills|11|num
items|bills|in
veto|including|mod
including|money|obj
hospitals|new york|nn
money|hospitals|for
break|tax|nn
hospitals|break|appo
growers|idaho|nn
growers|potato|nn
break|growers|for
projects|38|num
growers|projects|conj
projects|worth|pnmod
construction|military|mod
$287m|construction|in
construction|$144m|conj
bill|defense|nn
bill|spending|nn
$144m|bill|from
bill|and|punc
bill|$30m|conj
growers|intercepting|for
intercepting|asteroids|obj
overturned|line-item veto act|obj
overturned|by|by-subj
judge|u.s.|nn
judge|district|mod
overturned|judge|by
judge|thomas penfield jackson|person
judge|april 1997|in
overturned|and|punc
ruled|later|mod-before
overturned|ruled|conj
ruled|line-item veto act|subj
ruled|6-3|obj
6-3|as|mod
unconstitutional|u.s. supreme court|by
ruled|because|mod
because|allows|comp1
allows|it|subj
alter|president|subj
alter|law|obj
law|passage|after
creating|thereby|amod
law|new|mod
voted|not|mod-before
voted|law|subj
house|either|nn
house|congress|of
