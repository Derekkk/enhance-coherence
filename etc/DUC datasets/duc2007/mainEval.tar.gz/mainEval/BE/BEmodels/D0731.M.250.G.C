worked|1997|in
linda tripp|and|punc
linda tripp|monica lewinsky|conj
worked|linda tripp|subj
worked|white house|in
confided|monica|subj
linda|older|mod
confided|linda|in
confided|and|punc
confided|looked to|conj
looked to|monica|subj
looked to|her|obj
looked to|help|for
help|and|punc
help|advice|conj
recorded|linda|subj
conversations|40|num
conversations|telephone|nn
recorded|conversations|obj
conversations|totalling|rel
totalling|conversation|subj
hours|20|amount-value
totalling|hours|obj
hours|monica|with
monica|38|conj
38|her own|on
her own|and|punc
her own|2|conj
2|working|while
working|fbi|with
spoke of|tapes|on
spoke of|monica|subj
affair|her|gen
spoke of|affair|obj
affair|president|with
president|clinton|person
attempts|about|mod
attempts|cover|rel
cover|attempt|subj
cover|it|obj
cover|up|mod
brought|january 1998|in
brought|linda|subj
brought|tapes|obj
counsel|independent|mod
tapes|counsel|to
counsel|kenneth starr|person
counsel|who|whn
conducting|counsel|subj
investigation|ongoing|mod
conducting|investigation|obj
investigation|clinton|of
conducting|and|punc
conducting|told|conj
told|counsel|subj
told|him|obj
told|that|c
encouraged|monica|subj
encouraged|her|obj
encouraged|lie|mod
lie|monica|subj
lie|oath|under
tripp|ms.|title
granted|tripp|obj1
granted|immunity|obj2
prosecutor|special|mod
immunity|prosecutor|by
granted|and|punc
granted|testified|conj
testified|tripp|subj
jury|grand|nn
testified|jury|before
jury|july 1998|in
july 1998|which|whn
led to|july 1998|subj
hearings|congressional|mod
hearings|impeachment|nn
led to|hearings|obj
claimed|linda|subj
claimed|that|c
agent|new york|nn
agent|literary|mod
agent|lucianne goldberg|person
suggested|agent|subj
suggested|that|c
pass|she|subj
pass|tapes|obj
tapes|kenneth starr|to
talk|she|subj
talk|lawyers|to
representing|fin|subj
representing|paula jones|obj
paula jones|woman|appo
woman|suing|rel
suing|woman|subj
suing|clinton|obj
clinton|sexual harassment|for
suggested|widely|amod
suggested|that|c
motivation|linda|gen
motivation|revealing|for
revealing|tapes|obj
was|prospect|pred
deal|book|nn
prospect|deal|of
discussing|already|amod
discussing|she|subj
discussing|story|obj
story|goldberg|with
account|her|of
last|account|subj
last|moments|obj
moments|vince foster|with
counsel|deputy|nn
deputy|white house|person
vince foster|counsel|appo
counsel|who|whn
shot|counsel|subj
shot|himself|obj
shot|1993|in
co-worker|last|post
was|co-worker|pred
co-worker|see|rel
see|co-worker|subj
see|him|obj
tripp|ms|title
indicted|tripp|obj
indicted|july 1999|in
indicted|and|punc
indicted|charged|conj
charged|tripp|subj
taping|illegally|amod
charged|taping|with
taping|tripp|subj
conversation|december 1997|nn
conversation|phone|nn
taping|conversation|obj
conversation|monica|with
with|and|punc
with|for|conj
directing|illegally|amod
with|directing|for
attorney|her|gen
directing|attorney|obj
attorney|disclose|rel
disclose|attorney|subj
contents|its|gen
disclose|contents|obj
magazine|newsweek|nn
contents|magazine|to
dismissed|case|obj
evidence|insufficient|mod
dismissed|evidence|for
