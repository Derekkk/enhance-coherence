issued|1989|in
ayatollah khomeini|iran|of
issued|ayatollah khomeini|subj
sentence|death|nn
issued|sentence|obj
author|british|mod
sentence|author|on
author|salman rushdie|person
issued|because|mod
book|his|gen
book|satanic verses|title
insulted|"|punc
because|insulted|comp1
insulted|book|subj
sanctities|islamic|mod
insulted|sanctities|obj
was|born|pred
born|india|in
book|his|gen
banned|book|obj
application|his|gen
application|visit|for
denied|application|obj
would|not|neg
permit|british airways|subj
permit|rushdie|obj
rushdie|fly|rel
fly|rushdie|subj
airplanes|its|gen
fly|airplanes|on
pressures|diplomatic|mod
reacting|pressures|to
pressures|britian|by
britian|and|punc
european nations|other|mod
britian|european nations|conj
european nations|announced|pnmod
announced|1996|in
1996|that|c
sentence|death|nn
dropped|1996|obj2
dropped|sentence|obj1
president|rafsanjani|person
said|president|subj
said|was|fc
was|difference|pred
ruling|fatwa|nn
ruling|(|punc
difference|ruling|between
ruling|)|punc
ruling|and|punc
command|hokm|nn
command|(|punc
ruling|command|conj
did|not|neg
mean|khomeini|subj
mean|sentence|obj
be|command|pred
retraction|official|mod
continue|retraction|despite
sentence|death|nn
retraction|sentence|of
fundamentalists|iranian islamic|nn
continue|fundamentalists|subj
continue|demand|mod
demand|fundamentalist|subj
death|rushdie|gen
demand|death|obj
raised|khordad foundation|subj
raised|reward|obj
death|rushdie|gen
reward|death|for
death|2.5 million dollars|to
raised|and|punc
raised|announced|conj
announced|khordad foundation|obj
is|there|mod-before
is|nothing|pred
important|more|mod
nothing|important|pnmod
important|foundation|to
foundation|seeing|than
decree|imam khomeini|gen
seeing|executed|fc
executed|decree|subj
executed|"|punc
executed|1998|in
grand ayatollah lankarani|and|punc
grand ayatollah lankarani|grand ayatolla hamedani|conj
said|grand ayatollah lankarani|subj
said|enforced|fc
enforced|fatwa|obj
reverse|no one|subj
reverse|it|obj
more|half|than
half|iran|of
signed|parliament|subj
signed|letter|obj
letter|saying|rel
saying|letter|subj
sentence|death|nn
sentence|rushdie|against
stands|still|mod-before
saying|stands|fc
stands|sentence|subj
group|hard-line|mod
group|student|nn
offered|group|subj
offered|$333k|obj
$333k|anyone|to
anyone|who|whn
kills|anyone|subj
kills|salman rushdie|obj
residents|village|of
iran|northern|mod
village|iran|in
offered|residents|subj
offered|land|obj
land|and|punc
land|carpets|conj
carpets|anyone|to
anyone|who|whn
kills|anyone|subj
kills|him|obj
him|and|punc
him|thousands|conj
clerics|iranian|mod
thousands|clerics|of
clerics|and|punc
clerics|students|conj
salary|month|gen
salary|bounty|toward
said|february 2000|in
said|islamic revolutionary guard|subj
said|in|guest
said|radio|in
said|report|obj
report|that|c
sentence|death|nn
was|still|guest
was|in|pred
was|force|in
change|nothing|subj
change|it|obj
