was|october 1998|in
october 1998|matthew shepard|appo
student|gay|mod
student|21-year old|mod
student|university of wyoming|nn
student|college|nn
beaten|savagely|mod
was|beaten|pred
beaten|and|punc
beaten|tied|conj
tied|fence|to
temperatures|near-freezing|mod
fence|temperatures|in
died|he|subj
days|five|amount-value
later|days|amount-value
died|later|mod
lured|matthew|obj
lured|bar|out of
lured|and|punc
lured|attacked|conj
attacked|matthew|obj
attacked|by|by-subj
dropouts|two|nn
dropouts|high-school|nn
attacked|dropouts|by
dropouts|aaron mckinney|conj
aaron mckinney|22|conj
22|and|punc
22|russell henderson|conj
pleaded|henderson|subj
pleaded|guilty|desc
pleaded|and|punc
pleaded|sentenced|conj
sentenced|henderson|obj
terms|two|nn
terms|consecutive|mod
terms|life|nn
sentenced|terms|to
went|mckinney|subj
went|trial|to
went|found|conj
found|mckinney|obj1
found|guilty|desc
found|and|punc
found|sentenced|conj
sentenced|mckinney|obj
terms|two|nn
terms|consecutive|mod
terms|life|nn
sentenced|terms|to
galvanized|killing|subj
galvanized|gays|obj
gays|and|punc
gays|lesbians|conj
galvanized|nationwide|mod
marched|5,000|subj
marched|manhattan|in
vigils|candlelight|nn
vigils|and|punc
rallies|campus|nn
vigils|rallies|conj
took place|vigils|subj
took place|country|across
450|over|num-mod
bills|450|nn
bills|issues|on
issues|important|pnmod
important|gays|to
gays|and|punc
gays|lesbians|conj
introduced|bills|obj
introduced|legislatures|in
legislatures|country|across
country|1999|in
country|prompted|vrel
prompted|country|obj
prompted|part|in
part|murder|by
murder|matthew shepard|of
community|gay|mod
spokesmen|community|for
community|lashed|vrel
lashed|community|obj
lashed|out|mod
organizations|right-wing|nn
out|organizations|at
organizations|family research council|such as
lashed|and|punc
lashed|criticized|conj
criticized|community|subj
figures|public|mod
criticized|figures|obj
leader|then|mod
leader|senate|nn
leader|majority|nn
figures|leader|such as
leader|trent lott|person
leader|saying|for
is|sin|pred
sin|and|punc
people|gay|mod
sin|people|conj
saying|helped|fc
helped|fin|obj
helped|just|mod
just|alcoholics|like
alcoholics|or|punc
alcoholics|kleptomaniacs|conj
writer|new york times|nn
said|writer|subj
said|"|punc
said|once|punc
said|is|fc
scapegoated|successfully|mod
is|scapegoated|pred
threat|subhuman|mod
scapegoated|threat|as
to|"|punc
values|normal|mod
values|"|punc
take over|values|to
machine|propaganda|nn
values|machine|by
thugs|emboldened|mod
threat|take over|comp1
take over|thugs|subj
father|shepard|gen
urged|father|subj
adopt|congress|subj
adopt|legislation|obj
legislation|that|whn
extend|legislation|subj
protection|federal|mod
protection|hate-crime|mod
extend|protection|obj
protection|gays|to
gays|and|punc
gays|lesbians|conj
senate|u.s.|nn
approved|senate|subj
legislation|such|pre
approved|legislation|obj
legislation|but|punc
legislation|house|conj
2000|"|punc
2000|laramie project|appo
troupe|new york-based|mod
troupe|theater|nn
collaboration|troupe|between
troupe|and|punc
troupe|people|conj
people|laramie|of
received|well|amod
received|collaboration|obj
