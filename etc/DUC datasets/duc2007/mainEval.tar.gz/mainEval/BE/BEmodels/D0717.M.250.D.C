ahp|(|punc
american home products|ahp|abbrev
ahp|)|punc
received|american home products|subj
received|data|obj
data|mayo clinic|from
mayo clinic|february 1997|in
developed|patients|subj
damage|heart valve|nn
developed|damage|obj
damage|taking|after
taking|patient|subj
drug|its|gen
drug|"|punc
drug|fen-phen|nn
drug|"|punc
taking|drug|obj
drug|prescribed|pnmod
prescribed|obesity|for
taking|and|punc
taking|containing|conj
containing|patient|subj
fenflurmaine|compound|mod
containing|fenflurmaine|obj
pulled|september|in
pulled|fda|subj
pulled|fenfluramine|obj
fenfluramine|market|from
6.6 million|estimated|mod
market|6.6 million|after
used|people|subj
used|it|obj
used|stating|mod
stating|people|subj
stating|that|c
have|drug|subj
have|irreversibly|guest
irreversibly|and|punc
irreversibly|sometimes|conj
scarred|fatally|mod
users|scarred|mod
valves|users|gen
valves|heart|nn
have|valves|obj
by|2000|mid
filed|9,000|over
filed|lawsuits|obj
filed|ahp|against
suits|first|post
suits|dozen|mod
resulted|suits|subj
resulted|settlements|in
settlements|ranging|pnmod
ranging|$500,000|from
$500,000|$7 million|to
reported|largest|mod
settlement|reported|mod
went|settlement|subj
woman|55-year old|mod
woman|texas|nn
went|woman|to
woman|february 2000|in
woman|$8|for
$8|$9 million|to
residents|new jersey|nn
filed|residents|subj
suit|class|nn
suit|action|nn
filed|suit|obj
suit|seeking|rel
seeking|suit|subj
financial|not|mod
rewards|financial|mod
seeking|rewards|obj
rewards|but|punc
rewards|payment|conj
payment|medical checkups|for
people|healthy|mod
medical checkups|people|for
people|who|whn
taken|people|subj
taken|drug|obj
want|plaintiffs|subj
want|ahp|obj
ahp|cover|rel
cover|ahp|subj
cover|cost|obj
medical checkups|future|mod
cost|medical checkups|of
cover|in case|mod
in case|develop|comp1
develop|problems|subj
sued|also|amod
sued|ahp|obj
sued|by|by-subj
partner|its|gen
partner|marketing|nn
sued|partner|by
partner|interneuron pharmaceuticals|appo
interneuron pharmaceuticals|concealing|for
concealing|ahp|subj
concealing|risks|obj
risks|fen-phen|of
agreed|october 1999|in
agreed|ahp|subj
agreed|pay|fc
pay|ahp|subj
pay|$3.5 billion|obj
$3.5 billion|settle|rel
settle|$3.5 billion|subj
settle|thousands|obj
thousands|lawsuits|of
settle|nationwide|mod
approved|august 2000|in
judge|federal|mod
approved|judge|subj
approved|settlement|obj
users|fen-phen|mod
get up|users|subj
get up|$4.5 million|to
get up|depending on|mod
depending on|user|subj
level|their|gen
depending on|level|obj
level|injury|of
includes|settlement|subj
includes|money|obj
medical|future|mod
money|medical|for
people|estimated|mod
people|6 million|nn
people|who|whn
took|people|subj
took|drug|obj
45,000|about|mod
opted out|45,000|subj
settlement|nationwide|mod
opted out|settlement|of
opted out|and|punc
opted out|retained|conj
retained|45,000|subj
retained|right|obj
right|sue|comp1
sue|45,000|subj
sue|for|guest
damagesl|punitive|mod
sue|damagesl|for
sue|266,000|obj
266,000|registered|vrel
registered|266,000|obj
registered|join|mod
suit|class|nn
suit|action|nn
join|suit|obj
