foods|organic|mod
affected|not|guest
affected|which|obj
affected|by|by-subj
affected|radiation|by
radiation|genetic engineering|conj
genetic engineering|antibiotics|conj
antibiotics|pesticides|conj
pesticides|preservatives|conj
preservatives|hormones|conj
hormones|or|punc
additives|post-packaging|mod
hormones|additives|conj
ordered|congress|subj
standards|national|mod
standards|organic|mod
ordered|standards|obj
standards|1990|in
proposal|first|post
proposal|usda|nn
came in|proposal|subj
came in|1997|mod
came in|but|punc
came in|rejected|conj
rejected|proposal|obj
rejected|by|by-subj
rejected|industry|by
food|and|punc
food|use|conj
sludge|sewage|nn
use|sludge|of
sludge|fertilizer|as
be|organic|pred
certified|by|by-subj
state|88|num
state|different|mod
certified|state|by
certified|or|punc
certified|certifying|conj
certifying|agencies|obj
certifying|controls|with
controls|or|punc
inspections|on-site|mod
controls|inspections|conj
absence|labeling|of
labeling|hurt|obj1
labeling|exports|obj2
labeling|costing|mod
$200m|american|mod
$200m|farmers|nn
costing|$200m|obj
costing|annually|mod
costing|because|mod
modified|genetically|mod
corn|modified|mod
because|separated|comp1
separated|corn|obj
separated|rest|from
europeans|and|punc
europeans|japanese|conj
do|not|neg
want|europeans|subj
crops|gene-altered|mod
want|crops|obj
grew|90|in
sales|u.s.|nn
foods|organic|mod
sales|foods|of
grew|sales|subj
grew|20%|obj
grew|annually|mod
grew|exceeding|mod
exceeding|sale|subj
exceeding|$3.6 billion|obj
$3.6 billion|1996|in
acreage|crop|nn
doubled|acreage|subj
more|10,000|than
raising|farms|subj
crops|organic|mod
raising|crops|obj
crops|and|punc
crops|livestock|conj
eggs|organic|mod
production|eggs|of
eggs|and|punc
eggs|milk|conj
increased|production|subj
increased|even|mod
increased|more|mod
were|attacks|pred
e.g|conventional|mod
e.g|food|nn
e.g|industry|nn
e.g|(|punc
attacks|e.g|from
's|"|punc
's|saving|punc
's|the|punc
's|planet|punc
's|with|pred
's|pesticides|with
pesticides|and|punc
pesticides|plasic|conj
hudson instutute|1995|num
hudson instutute|)|punc
hudson instutute|but|punc
hudson instutute|participation|conj
participation|companies|by
companies|general|such as
general|mills|person
general|and|punc
chains|grocery|nn
general|chains|conj
chains|albertsons|such as
krogers|and|punc
krogers|winn-dixie|conj
were|evidence|pred
evidence|that|c
food|organic|mod
joined|food|subj
joined|mainstream|obj
standards|new usda|nn
finalized|standards|obj
finalized|late 2000|in
finalized|and|punc
finalized|put|conj
put|standards|obj
put|effect|into
months|18|amount-value
later|months|amount-value
put|later|mod
glickman|agriculture secretary|nn
said|glickman|subj
standards|new|mod
said|be|fc
rules|"|punc
comprehensive|most|mod
rules|comprehensive|mod
rules|strictest|mod
rules|organic|mod
be|rules|pred
rules|world|in
products|meeting|rel
meeting|product|subj
meeting|standard|obj
labeled|products|obj1
labeled|"|punc
labeled|usda certified organic|obj2
budget|usda|gen
budget|new|mod
included|budget|subj
request|$5.5 million|nn
included|request|obj
research|organic|mod
request|research|for
