began|1996|in
began|u.s.|subj
began|restructuring|guest
restructuring|u.s.|subj
restructuring|its|obj
began|ballistic missile defense|obj
bmd|(|punc
ballistic missile defense|bmd|abbrev
bmd|)|punc
version|scaled-back|mod
ballistic missile defense|version|to
program|space-based|mod
program|strategic defense initiative|nn
program|"|punc
program|star wars|nn
program|"|punc
version|program|of
program|proposed|pnmod
proposed|president|by
president|reagan|person
president|1993|in
signed|u.s.|subj
treaty|anti-ballistic-missile|nn
signed|treaty|obj
treaty|soviet union|with
soviet union|1972|in
signed|but|punc
signed|wants|conj
wants|u.s.|subj
wants|modify|fc
modify|u.s.|subj
modify|treaty|obj
treaty|develop|rel
develop|treaty|subj
develop|defenses|obj
defenses|attacks|against
states|rogue|nn
attacks|states|by
states|iran|such as
iran|and|punc
iran|north korea|conj
warned|may 2000|in
president|russian|mod
president|putin|person
warned|president|subj
warned|that|obj
warned|if|c
withdraws|u.s.|subj
withdraws|1972|from
1972|withdraw|rel
withdraw|1972|obj
withdraw|treaty|subj
withdraw|start ii treaty|from
from|and|punc
from|from|conj
system|whole|mod
from|system|from
system|treaties|of
treaties|limitation|on
limitation|and|punc
limitation|control|conj
weapons|strategic|mod
strategic|and|punc
strategic|conventional|conj
control|weapons|of
specialists|control|nn
fear|specialists|subj
fear|compel|fc
compel|this|subj
expand|china|subj
expand|and|punc
expand|modernize|conj
modernize|china|subj
program|their|gen
program|missile|nn
modernize|program|obj
program|and|punc
program|that|conj
reaction|chain|nn
reaction|nuclear weapons|of
proliferation|including|rel
including|proliferation|subj
including|india|obj
india|and|punc
india|pakistan|conj
ensue|proliferation|subj
cost|system|of
interceptors|100|num
interceptors|missile|nn
system|interceptors|with
site|single|mod
interceptors|site|at
site|alaska|in
estimated|cost|obj
be|$36 billion|pred
$60 billion|two|for
phase|first|post
failed|phase|during
phase|development|of
attempts|six|nn
attempts|test|mod
attempts|hit|rel
hit|attempt|subj
hit|flying|obj1
hit|target|obj2
failed|attempts|subj
test|first|post
test|successful|mod
was|in|pred
was|june 1999|in
test|successful|mod
's|test|by
test|involving|rel
involving|test|subj
warhead|separated|mod
involving|warhead|obj
involving|outside|mod
's|atmosphere|pred
atmosphere|august|in
tests|two|nn
tests|january|in
january|and|punc
january|august 2000|conj
failed|tests|subj
study|mit|by
mit|and|punc
mit|union of concerned scientists|conj
union of concerned scientists|2000|in
concluded|study|subj
concluded|that|c
system|proposed|mod
system|bmd|nn
fooled|easily|amod
fooled|system|obj
fooled|by|by-subj
decoys|simple|mod
fooled|decoys|by
decoys|or|punc
countermeasures|other|mod
decoys|countermeasures|conj
committee|british|mod
urged|committee|subj
seek|u.s.|subj
ways|other|mod
seek|ways|mod
seek|reducing|of
reducing|u.s.|subj
threats|perceived|mod
reducing|threats|obj
