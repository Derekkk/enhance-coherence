satisfy|inf|subj
judgement|$33.5m|nn
judgement|civil|mod
judgement|court|nn
satisfy|judgement|obj
judgement|him|against
him|o.j|appo
possessions|simpon|gen
seized|possessions|obj
seized|internet|on
seized|raising|mod
raising|possession|subj
raising|total|obj
total|$430,000|of
heisman trophy|his|gen
was|heisman trophy|pred
heisman trophy|sold|vrel
sold|heisman trophy|obj
sold|$230,000|at
jerseys|two|nn
jerseys|no. 32|nn
jerseys|football|nn
certificate|football|nn
certificate|hall of fame|nn
jerseys|certificate|conj
certificate|and|punc
trophies|two|nn
certificate|trophies|conj
purchased|jerseys|obj
purchased|$16,000|for
burned|then|mod-before
$16,000|burned|vrel
burned|$16,000|obj
burned|steps|on
steps|los angeles courthouse|of
los angeles courthouse|protest|as
protest|failure|against
system|criminal|mod
system|justice|nn
failure|system|in
offered|june 2000|in
offered|simpson|subj
offered|take|mod
take|simpson|subj
test|lie detector|nn
take|test|obj
take|if|c
puts up|someone|subj
reward|$3m|nn
puts up|reward|obj
reward|catch|rel
catch|reward|subj
ex-wife|his|gen
killer|ex-wife|gen
catch|killer|obj
was|april 1999|in
custody|given|mod
was|custody|pred
children|his|gen
children|two|nn
custody|children|of
sydney|13-year-old|mod
children|sydney|conj
sydney|and|punc
justin|10-year-old|mod
sydney|justin|conj
justin|who|whn
were|in|pred
were|custody|in
family|brown|mod
custody|family|of
year|simpson|gen
family|year|during
family|jail|in
asked|august 1999|in
sister|nicole|gen
sister|and|punc
lawyer|her|gen
sister|lawyer|conj
asked|sister|subj
attorney|state|nn
asked|attorney|obj1
asked|general|obj2
general|investigate|rel
investigate|general|subj
charges|perjury|nn
investigate|charges|obj
charges|simpson|against
testimony|his|gen
simpson|testimony|for
testimony|that|c
hit|never|mod-before
hit|he|subj
hit|struck|conj
struck|he|subj
struck|or|punc
struck|slapped|conj
slapped|he|subj
slapped|nicole|obj
made|july 2000|in
made|simpson|subj
appearance|internet|nn
appearance|chat|nn
made|appearance|obj
appearance|aimed at|vrel
aimed at|appearance|obj
aimed at|convincing|mod
convincing|simpson|subj
convincing|public|obj
convincing|that|c
kill|he|subj
ex-wife|his|gen
kill|ex-wife|obj
ex-wife|and|punc
friend|her|gen
ex-wife|friend|conj
scheduled|also|amod
scheduled|he|obj
scheduled|appear|mod
appear|he|subj
appear|nbc|on
appear|today|mod
the view|abc|gen
the view|"|punc
the view|"|punc
the view|and|punc
the view|fox|conj
's|"|punc
's|edge|pred
edge|"|punc
edge|but|punc
edge|abc|conj
alt.fan.oj-simpson|internet|nn
alt.fan.oj-simpson|newsgroup|nn
continue|alt.fan.oj-simpson|on
members|645|num
continue|members|subj
debate|daily|mod
continue|debate|obj
debate|minutiae|on
guilt|his|gen
minutiae|guilt|of
guilt|or|punc
guilt|innocence|conj
lost|september 2000|in
lost|simpson|subj
lost|bid|obj
bid|court|in
court|stop|rel
stop|court|subj
stop|broadcast|obj
of|"|punc
tragedy|american|nn
broadcast|tragedy|of
tragedy|"|punc
miniseries|television|nn
tragedy|miniseries|conj
miniseries|author|by
author|lawrence schiller|person
miniseries|and|punc
miniseries|robert kardashian|conj
lawyer|his|gen
lawyer|former|mod
lawyer|defense|nn
tragedy|lawyer|appo
