action|antitrust|mod
action|microsoft|against
ongoing|1990|since
reached|1994|in
reached|justice department|subj
reached|settlement|obj
settlement|microsoft|with
microsoft|requiring|rel
requiring|microsoft|subj
requiring|company|obj
company|change|rel
change|company|subj
practices|its|gen
practices|business|mod
change|practices|obj
sued|1995|in
sued|justice|subj
sued|to|guest
sued|block|to
acquisition|microsoft|gen
sued|acquisition|obj
acquisition|intuit|of
launched|october 1996|in
government|u.s.|nn
government|and|punc
states|20|num
government|states|conj
launched|government|subj
launched|trial|obj
trial|accusing|rel
accusing|trial|subj
accusing|microsoft|obj
activities|illegal|mod
microsoft|activities|of
activities|including|rel
including|activity|subj
competitors|bullying|mod
including|competitors|obj
sued|sun microsystems|subj
sued|microsoft|obj
microsoft|violating|for
violating|sun microsystems|subj
agreement|their|gen
violating|agreement|obj
agreement|related|vrel
related|agreement|obj
language|java|nn
language|programming|nn
related|language|to
sued|caldera linux|subj
sued|microsoft|obj
efforts|its|gen
microsoft|efforts|for
efforts|quash|rel
quash|effort|subj
dos|dr.|title
quash|dos|obj
dos|competitor|appo
competitor|microsoft dos|with
ruled|april 2000|in
judge|thomas penfield jackson|person
ruled|judge|subj
ruled|that|c
violated|microsoft|subj
act|sherman|nn
act|antitrust|mod
violated|act|obj
wrote|he|subj
maintained|company|subj
power|its|gen
power|monopoly|nn
maintained|power|obj
means|anti-competitive|mod
power|means|by
maintained|attempted|conj
attempted|company|subj
attempted|monopolize|fc
monopolize|company|subj
market|web|nn
market|browser|nn
monopolize|market|obj
attempted|and|punc
tied|unlawfully|mod-before
attempted|tied|conj
tied|company|subj
browser|its|gen
browser|web|nn
tied|browser|obj
browser|operating system|to
justice department|and|punc
general|17|num
general|state attorneys|nn
justice department|general|conj
proposed|justice department|subj
proposed|breaking|fc
breaking|justice department|subj
breaking|microsoft|obj
breaking|up|mod
companies|two|nn
up|companies|into
one|holding|rel
holding|one|subj
holding|operating system|obj
everything|other|mod
judge|jackson|person
agreed|judge|subj
agreed|proposal|with
division|justice department|gen
division|anti-trust|mod
head|division|of
said|head|subj
said|committed|fc
committed|department|obj
finding|department|subj
finding|remedy|obj
remedy|that|whn
protect|remedy|subj
protect|consumers|obj
consumers|putting an end to|by
abuse|microsoft|gen
putting an end to|abuse|obj
powers|monopoly|nn
abuse|powers|of
putting an end to|and|punc
putting an end to|rectify|conj
attempt|its|gen
attempt|unlawful|mod
rectify|attempt|obj
attempt|monopolize|rel
monopolize|attempt|subj
market|web|nn
market|browser|nn
monopolize|market|obj
announced|bill gates|subj
announced|that|c
company|his|gen
appeal|company|subj
appeal|verdict|obj
verdict|which|whn
characterized|verdict|obj
attack|anti-capitalist|mod
characterized|attack|as
attack|that|whn
be|against|pred
interest|public|mod
be|interest|against
dangerous|welfare|for
welfare|economy|of
