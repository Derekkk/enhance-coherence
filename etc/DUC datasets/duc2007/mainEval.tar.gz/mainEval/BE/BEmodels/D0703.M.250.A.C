nations|european union|nn
eu|(|punc
european union|eu|abbrev
eu|)|punc
agreed|nations|subj
agreed|that|c
currency|single|mod
currency|(|punc
currency|euro|appo
go into|)|punc
go into|currency|subj
go into|effect|obj
effect|january 1 , 1999|on
indicate|polls|subj
support|but|punc
skepticism|widespread|mod
support|skepticism|conj
indicate|remains|fc
remains|support|subj
countries|six|nn
eighty percent|countries|in
say|eighty percent|subj
are|not|neg
informed|well|amod
say|informed|fc
informed|they|obj
worry about|economists|subj
worry about|loss|obj
sovereignty|financial|mod
loss|sovereignty|of
worry about|others|subj
unemployment|rising|mod
worry about|unemployment|obj
unemployment|and|punc
rates|interest|nn
unemployment|rates|conj
say|proponents|subj
say|guarantee|fc
guarantee|euro|subj
stability|currency|nn
guarantee|stability|obj
guarantee|lower|conj
lower|euro|subj
rates|interest|nn
lower|rates|obj
lower|and|punc
lower|contribute to|conj
contribute to|euro|subj
contribute to|unity|obj
unity|eu|of
spain|france|conj
france|ireland|conj
ireland|italy|conj
italy|luxemboug|conj
luxemboug|netherlands|conj
netherlands|austria|conj
austria|portugal|conj
portugal|and|punc
portugal|finland|conj
founding|spain|subj
founding|members|obj
club|euro|nn
members|club|of
britain|and|punc
britain|demark|conj
opted out|britain|subj
opted out|while|mod
greece|and|punc
greece|sweden|conj
while|judged|comp1
not|economically|mod
ready|not|mod-before
ready|greece|subj
ready|join|mod
join|britain|subj
rival|euro|subj
dollar|u.s.|nn
rival|dollar|obj
currency|international|mod
dollar|currency|as
rival|but|punc
will|not|neg
rival|replace|conj
replace|euro|subj
dollar|u.s.|nn
replace|dollar|obj
dollar|choice|as
reserves|foreign|mod
choice|reserves|for
transactions|initial|mod
be|cashless|pred
notes|bank|nn
notes|and|punc
notes|coins|conj
become|notes|subj
january 1st 2002|legal tender|nn
become|january 1st 2002|obj
become|while|mod
currencies|national|mod
while|stop|comp1
stop|currencies|subj
stop|circulating|mod
circulating|currency|subj
circulating|july 1st 2002|by
france|finland|conj
finland|belgium|conj
belgium|and|punc
belgium|spain|conj
started|france|subj
started|production|obj
production|euro|of
coins|70 billion|nn
total|coins|of
issued|total|obj
issued|replace|mod
replace|total|subj
currencies|national|mod
replace|currencies|obj
vatican|and|punc
vatican|monaco|conj
entitled|vatican|obj
entitled|use|mod
use|vatican|subj
use|euro|obj
currency|their|gen
currency|official|mod
euro|currency|as
entitled|but|punc
entitled|issue|conj
issue|vatican|subj
issue|currency|obj
issue|unless|mod
unless|agree|comp1
agree|they|subj
conditions|eu|nn
agree|conditions|to
design|euro|of
required|design|obj
required|include|mod
include|design|subj
languages|five|nn
include|languages|obj
languages|symbol|appo
symbol|eu|of
eu|(|punc
stars|12|num
eu|stars|appo
stars|ring|in
required|)|punc
required|and|punc
required|feature|conj
feature|design|subj
feature|bridges|obj
bridges|windows|conj
windows|and|punc
windows|doorways|conj
styles|various|mod
styles|european|mod
doorways|styles|in
be|"|punc
code|currency|nn
be|code|pred
