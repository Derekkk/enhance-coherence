European Union (EU) nations agreed that a single currency (the Euro) will go into effect on January 1, 1999.
Polls indicate support but widespread skepticism remains.
Eighty percent in six countries say they are not well informed.
Some economists worry about loss of financial sovereignty; others worry about rising unemployment and interest rates.
Proponents say the Euro will guarantee currency stability, lower interest rates and contribute to the unity of the EU.
The design of the Euro is required to include five languages and the symbol of the EU.
"EUR" will be the currency code.
