The trial of Aaron McKinney began in October 1999.
His defense attorneys maintained that Aaron's judgement on the night of the murder was affected by alcohol, methamphetamines and sexually traumatic events in his life which caused him to react in a moment of rage or "gay panic." The prosecution countered by saying there could not be a conspiracy of two people who pretend to be homosexuals, commit a robbery and murder, then claim homosexual panic.
Over 450 bills have been introduced in legislatures across the country in 1999, prompted in part by the murder of Matthew Shepard.
