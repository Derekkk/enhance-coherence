State District Judge Barton Voigt barred McKinney's defense lawyers from using a "gay panic" defense, saying it was, in effect, a temporary insanity or diminished capacity defense, both of which are prohibited under Wyoming law.
The jury convicted McKinney of murder, kidnapping and robbery.
The prosecution asked for the death sentence, but Shepard's parents agreed to two consecutive life terms.
Shepard's father asked Congress to extend federal hate crime legislation to protect homosexuals.
The Senate approved the legislation, but the House did not.
In 2000, "The Laramie Project," a play about Shepard's murder went on stage in Wyoming.
