In November 1998, the U.N.
World Heritage Bureau, after intense lobbying by the Australian government, decided not to put the Kakadu National Park on its endangered list, but asked for a detailed report by April 15th 1999 on what has been done to prevent further damage and mitigate all threats to the Kakadu park by the Jabiluka mine.
Environment Minister Robert Hill said the UNESCO report was made after just a four day visit to the area and ignored a large volume of evidence gathered over 18 years of mining at the nearby Ranger mine.
