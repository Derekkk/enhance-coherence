In October 1998, Matthew Shepard, a gay, 21-year old University of Wyoming college student was savagely beaten and tied to a fence in near-freezing temperatures.
He died five days later.
Matthew was lured out of a bar and attacked by two high-school dropouts, Aaron McKinney, 22 and Russell Henderson, 21.
McKinney was quoted as saying "It's Gay Awareness Week," as he beat Shepard.
The killing galvanized gays and lesbians nationwide.
Over 5,000 marched in Manhattan; candlelight vigils and campus rallies took place across the country.
Russel Henderson pleaded guilty and was sentenced to two consecutive life terms.
