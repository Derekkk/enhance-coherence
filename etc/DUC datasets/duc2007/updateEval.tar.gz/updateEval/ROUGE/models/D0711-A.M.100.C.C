In Sepember 1996, the Justice Department renewed its antitrust investigation of Microsoft after Netscape Corporation asked regulators to examine violations in the marketing of Internet Explorer.
In June 1998, the U.S. Court of Appeals gave Microsoft the right to tie its internet software to the operating system.
In October, The U.S. Government and 20 states launched a trial accusing Microsoft of illegal activities including bullying competitors.
IBM produced evidence that Microsoft offered lower prices for Windows if IBM would drop its competing operating system, OS/2.
Gary Norris of IBM presented dates, places, names and substantiated evidence with handwritten notes.
