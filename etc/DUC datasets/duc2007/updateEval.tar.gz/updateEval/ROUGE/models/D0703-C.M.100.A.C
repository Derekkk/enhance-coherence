Romania's Central Bank decided to include the Euro in their exchange rates while Bulgaria decided to formally back their lev by Euros.
The Reserve Bank of India gave permission for its banks to transact in Euro.
France, Finland, Belgium and Spain have started production of Euro's.
A total of 70 billion coins should be issued.
The Vatican, San Marino and Monaco are entitled to use the Euro as their official currency but cannot issue any currency unless they agree to EU conditions.
The currency will feature bridges, windows and doorways in various European styles.
