renewed|sepember 1996|in
renewed|justice department|subj
investigation|its|gen
investigation|antitrust|mod
renewed|investigation|obj
investigation|microsoft|of
renewed|after|mod
after|asked|comp1
asked|netscape corporation|subj
asked|regulators|obj
regulators|examine|rel
examine|regulator|subj
examine|violations|obj
violations|marketing|in
marketing|internet explorer|of
gave|june 1998|in
of appeals|u.s.|nn
gave|of appeals|subj
gave|microsoft|obj1
gave|right|obj2
right|tie|comp1
tie|court of appeals|subj
software|its|gen
software|internet|nn
tie|software|obj
software|operating system|to
launched|october|in
government|u.s.|nn
government|and|punc
states|20|num
government|states|conj
launched|government|subj
launched|trial|obj
trial|accusing|rel
accusing|trial|subj
accusing|microsoft|obj
activities|illegal|mod
microsoft|activities|of
activities|including|rel
including|activity|subj
competitors|bullying|mod
including|competitors|obj
produced|ibm|subj
produced|evidence|obj
evidence|that|c
offered|microsoft|subj
prices|lower|mod
offered|prices|obj
prices|windows|for
offered|if|c
drop|ibm|subj
operating system|its|gen
operating system|competing|mod
drop|operating system|obj
operating system|os/2|appo
gary norris|ibm|of
presented|gary norris|subj
presented|dates|obj
dates|places|conj
places|names|conj
names|and|punc
evidence|substantiated|mod
names|evidence|conj
notes|handwritten|mod
places|notes|with
