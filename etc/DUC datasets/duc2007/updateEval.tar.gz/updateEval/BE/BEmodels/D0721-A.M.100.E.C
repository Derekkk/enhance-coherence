was|october 1998|in
october 1998|matthew shepard|appo
student|gay|mod
student|21-year old|mod
student|university of wyoming|nn
student|college|nn
beaten|savagely|mod
was|beaten|pred
beaten|and|punc
beaten|tied|conj
tied|fence|to
temperatures|near-freezing|mod
fence|temperatures|in
died|he|subj
days|five|amount-value
later|days|amount-value
died|later|mod
lured|matthew|obj
lured|bar|out of
lured|and|punc
lured|attacked|conj
attacked|matthew|obj
attacked|by|by-subj
dropouts|two|nn
dropouts|high-school|nn
attacked|dropouts|by
dropouts|aaron mckinney|conj
aaron mckinney|22|conj
22|and|punc
22|russell henderson|conj
quoted|mckinney|obj
saying|mckinney|subj
saying|"|punc
saying|'s|fc
's|gay awareness week|pred
's|"|punc
's|as|mod
as|beat|comp1
beat|he|subj
beat|shepard|obj
galvanized|killing|subj
galvanized|gays|obj
gays|and|punc
gays|lesbians|conj
galvanized|nationwide|mod
marched|5,000|subj
marched|manhattan|in
vigils|candlelight|nn
vigils|and|punc
rallies|campus|nn
vigils|rallies|conj
took place|vigils|subj
took place|country|across
pleaded|russel henderson|subj
pleaded|guilty|desc
pleaded|and|punc
pleaded|sentenced|conj
sentenced|russel henderson|obj
terms|two|nn
terms|consecutive|mod
terms|life|nn
sentenced|terms|to
