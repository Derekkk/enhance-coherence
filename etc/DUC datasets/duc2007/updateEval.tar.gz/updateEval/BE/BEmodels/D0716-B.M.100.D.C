series|protests|of
followed|series|subj
followed|start|obj
start|work|of
mine|jabiluka|nn
mine|uranium|nn
work|mine|at
mine|and|punc
mine|firebombs|conj
firebombs|caused|vrel
caused|firebombs|obj
caused|more|mod
damage|100,000|num
damage|australian dollars|nn
more|damage|than
office|darwin era|nn
damage|office|to
visited|october 1998|in
team|eight-member|mod
team|united nations world heritage bureau|from
visited|team|subj
visited|site|obj
visited|and|punc
visited|spoke|conj
spoke|team|subj
groups|interest|nn
spoke|groups|to
spoke|including|mod
including|team|subj
including|era|obj
called for|bureau|subj
called for|closing|mod
closing|bureau|subj
mine|jabiluka|nn
closing|mine|obj
closing|because|mod
because|poses|comp1
poses|it|subj
poses|danger|obj
values|cultural|mod
cultural|and|punc
cultural|natural|conj
danger|values|to
values|kakadu national park|of
minister|australian|mod
minister|environment|nn
blasted|minister|subj
blasted|report|obj
report|as|mod
unbalanced|and|punc
unbalanced|lacking|conj
lacking|objectivity|in
